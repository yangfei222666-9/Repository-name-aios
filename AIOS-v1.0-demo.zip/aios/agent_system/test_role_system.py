"""
测试 Agent 角色系统
对比有角色 vs 无角色的效果
"""

import json
import sys
from pathlib import Path

# 添加路径
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from aios.agent_system.auto_dispatcher import AutoDispatcher


def test_role_injection():
    """测试角色信息注入"""
    workspace = Path(__file__).parent.parent.parent
    dispatcher = AutoDispatcher(workspace)

    # 创建测试任务
    task = {
        "id": "test_role_001",
        "type": "code",
        "message": "Write a Python function to calculate fibonacci numbers",
        "priority": "normal",
        "source": "test",
    }

    # 分发任务
    print("=== 测试任务分发 ===")
    print(f"任务类型: {task['type']}")
    print(f"原始消息: {task['message']}")
    print()

    try:
        result = dispatcher._dispatch_task(task)
        print(f"分发结果: {result}")
        print()

        # 读取生成的 spawn_request
        spawn_file = workspace / "aios" / "agent_system" / "spawn_requests.jsonl"
        if spawn_file.exists():
            with open(spawn_file, "r", encoding="utf-8") as f:
                lines = f.readlines()
                if lines:
                    last_request = json.loads(lines[-1])
                    print("=== 生成的 Spawn Request ===")
                    print(f"Task ID: {last_request['task_id']}")
                    print(f"Label: {last_request['label']}")
                    print(f"Model: {last_request['model']}")
                    print(f"Role: {last_request.get('role', 'N/A')}")
                    print(f"Goal: {last_request.get('goal', 'N/A')}")
                    print()
                    print("=== 增强后的消息 ===")
                    print(last_request['message'])
                    print()

    except Exception as e:
        print(f"错误: {e}")
        import traceback
        traceback.print_exc()


def test_config_loading():
    """测试配置加载"""
    workspace = Path(__file__).parent.parent.parent
    dispatcher = AutoDispatcher(workspace)

    print("=== Agent 配置 ===")
    for agent_id, config in dispatcher.agent_configs.items():
        print(f"\n{agent_id}:")
        print(f"  Type: {config.get('type')}")
        print(f"  Role: {config.get('role', 'N/A')}")
        print(f"  Goal: {config.get('goal', 'N/A')[:50]}...")
        print(f"  Backstory: {config.get('backstory', 'N/A')[:50]}...")


if __name__ == "__main__":
    print("=" * 60)
    print("Agent 角色系统测试")
    print("=" * 60)
    print()

    test_config_loading()
    print()
    print("=" * 60)
    print()
    test_role_injection()
