#!/usr/bin/env python3
"""
Test the 5 Learning Agents setup

1. Creates test data
2. Runs the learning orchestrator
3. Verifies the output
"""

import subprocess
import sys
from pathlib import Path

AIOS_ROOT = Path(__file__).resolve().parent.parent
python_exe = r"C:\Program Files\Python312\python.exe"

print("=" * 80)
print("Testing 5 Learning Agents Setup")
print("=" * 80)
print()

# Step 1: Create test data
print("[1/3] Creating test data...")
result = subprocess.run(
    [python_exe, str(AIOS_ROOT / "agent_system" / "create_test_data.py")],
    capture_output=True,
    text=True,
    encoding='utf-8',
    errors='replace'
)
print(result.stdout)
if result.returncode != 0:
    print(f"ERROR: {result.stderr}")
    sys.exit(1)

# Step 2: Run learning orchestrator
print("[2/3] Running learning orchestrator...")
result = subprocess.run(
    [python_exe, "-X", "utf8", str(AIOS_ROOT / "agent_system" / "learning_orchestrator_simple.py")],
    capture_output=True,
    text=True,
    encoding='utf-8',
    errors='replace'
)
print(result.stdout)
if result.returncode != 0:
    print(f"ERROR: {result.stderr}")
    sys.exit(1)

# Step 3: Check agents_data.json
print("[3/3] Verifying agents registration...")
import json
agents_file = AIOS_ROOT / "agent_system" / "agents_data.json"
with open(agents_file, 'r', encoding='utf-8') as f:
    agents_data = json.load(f)

learning_agents = [a for a in agents_data["agents"] if a["id"].startswith("learner-")]
print(f"Found {len(learning_agents)} learning agents:")
for agent in learning_agents:
    print(f"  - {agent['id']}: {agent['name']}")

print()
print("=" * 80)
print("Test completed successfully!")
print("=" * 80)
