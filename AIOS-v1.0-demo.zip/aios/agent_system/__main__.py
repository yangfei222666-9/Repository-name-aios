"""
AIOS Agent System CLI 入口
"""

from . import main

if __name__ == "__main__":
    main()
