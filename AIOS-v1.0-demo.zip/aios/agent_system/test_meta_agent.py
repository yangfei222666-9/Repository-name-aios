"""
Meta-Agent 测试套件
"""

import json
import sys
import tempfile
import shutil
from pathlib import Path
from datetime import datetime, timedelta

# 路径设置
sys.path.insert(0, str(Path(__file__).resolve().parent))

from meta_agent import MetaAgent
from dynamic_registry import DynamicRegistry


def setup_test_workspace():
    """创建临时测试工作区"""
    tmp = Path(tempfile.mkdtemp(prefix="meta_agent_test_"))
    
    # 创建目录结构
    (tmp / "aios" / "agent_system" / "data" / "traces").mkdir(parents=True)
    (tmp / "aios" / "agent_system" / "data" / "meta_agent").mkdir(parents=True)
    (tmp / "memory").mkdir(parents=True)
    
    # 复制模板
    src_tpl = Path(__file__).resolve().parent / "agent_templates.json"
    if src_tpl.exists():
        shutil.copy(src_tpl, tmp / "aios" / "agent_system" / "agent_templates.json")
    
    return tmp


def cleanup(tmp: Path):
    """清理测试工作区"""
    try:
        shutil.rmtree(tmp)
    except Exception:
        pass


def test_registry_basic():
    """测试 1: Registry 基本操作"""
    tmp = setup_test_workspace()
    try:
        reg = DynamicRegistry(tmp)
        
        # 注册
        result = reg.register("test-001", {"type": "coder", "name": "Test Coder"})
        assert result["ok"], f"Register failed: {result}"
        assert reg.active_count() == 1
        
        # 查询
        agent = reg.get_agent("test-001")
        assert agent is not None
        assert agent["config"]["type"] == "coder"
        
        # 注销
        result = reg.unregister("test-001", "test")
        assert result["ok"]
        assert reg.active_count() == 0
        
        print("✅ test_registry_basic")
    finally:
        cleanup(tmp)


def test_registry_max_limit():
    """测试 2: Agent 数量上限"""
    tmp = setup_test_workspace()
    try:
        reg = DynamicRegistry(tmp)
        
        # 注册 15 个
        for i in range(15):
            result = reg.register(f"agent-{i:03d}", {"type": "test"})
            assert result["ok"], f"Register {i} failed"
        
        # 第 16 个应该失败
        result = reg.register("agent-015", {"type": "test"})
        assert not result["ok"]
        assert "limit" in result["error"].lower()
        
        print("✅ test_registry_max_limit")
    finally:
        cleanup(tmp)


def test_registry_cleanup_idle():
    """测试 3: 闲置清理"""
    tmp = setup_test_workspace()
    try:
        reg = DynamicRegistry(tmp)
        
        # 注册并手动设置 last_active 为 2 天前
        reg.register("old-agent", {"type": "test"})
        old_time = (datetime.now() - timedelta(hours=48)).isoformat()
        reg._registry["agents"]["old-agent"]["last_active"] = old_time
        reg._save_registry()
        
        # 注册一个新的
        reg.register("new-agent", {"type": "test"})
        
        # 清理 24h 闲置
        cleaned = reg.cleanup_idle(24)
        assert "old-agent" in cleaned
        assert "new-agent" not in cleaned
        assert reg.active_count() == 1
        
        print("✅ test_registry_cleanup_idle")
    finally:
        cleanup(tmp)


def test_registry_protected():
    """测试 4: 受保护 Agent 不被清理"""
    tmp = setup_test_workspace()
    try:
        reg = DynamicRegistry(tmp)
        
        reg.register("protected-agent", {"type": "test", "protected": True})
        old_time = (datetime.now() - timedelta(hours=48)).isoformat()
        reg._registry["agents"]["protected-agent"]["last_active"] = old_time
        reg._save_registry()
        
        cleaned = reg.cleanup_idle(24)
        assert "protected-agent" not in cleaned
        assert reg.active_count() == 1
        
        print("✅ test_registry_protected")
    finally:
        cleanup(tmp)


def test_meta_detect_gaps():
    """测试 5: 缺口检测"""
    tmp = setup_test_workspace()
    try:
        meta = MetaAgent(tmp)
        gaps = meta.detect_gaps()
        
        # 应该检测到模板缺口（所有模板都没有活跃 Agent）
        template_gaps = [g for g in gaps if g["gap_type"] == "template_uncovered"]
        assert len(template_gaps) > 0, "Should detect template gaps"
        
        print("✅ test_meta_detect_gaps")
    finally:
        cleanup(tmp)


def test_meta_design_from_template():
    """测试 6: 从模板设计 Agent"""
    tmp = setup_test_workspace()
    try:
        meta = MetaAgent(tmp)
        
        gap = {
            "gap_type": "template_uncovered",
            "agent_type": "coder",
            "template": "coder",
            "description": "No active coder agent",
            "severity": "medium"
        }
        
        design = meta.design_agent(gap)
        assert design is not None
        assert design["source"] == "template"
        assert design["config"]["type"] == "coder"
        assert design["config"]["model"] == "claude-opus-4-5"
        assert design["risk_level"] == "low"
        
        print("✅ test_meta_design_from_template")
    finally:
        cleanup(tmp)


def test_meta_design_custom():
    """测试 7: 自定义设计"""
    tmp = setup_test_workspace()
    try:
        meta = MetaAgent(tmp)
        
        gap = {
            "gap_type": "frequent_failure",
            "agent_type": "deployment",
            "description": "Deployment tasks failing",
            "severity": "high"
        }
        
        design = meta.design_agent(gap)
        assert design is not None
        assert design["source"] == "custom"
        assert design["config"]["env"] == "sandbox"  # 自定义先在沙盒
        assert design["risk_level"] == "medium"
        
        print("✅ test_meta_design_custom")
    finally:
        cleanup(tmp)


def test_meta_sandbox_pass():
    """测试 8: 沙盒测试通过"""
    tmp = setup_test_workspace()
    try:
        meta = MetaAgent(tmp)
        
        design = {
            "agent_id": "test-001",
            "source": "template",
            "config": {
                "type": "coder",
                "name": "Test Coder",
                "model": "claude-sonnet-4-5",
                "timeout": 120,
                "tools_allow": ["exec", "read"],
                "tools_deny": ["gateway", "cron"]
            }
        }
        
        result = meta.sandbox_test(design)
        assert result["passed"], f"Should pass: {result['tests']}"
        
        print("✅ test_meta_sandbox_pass")
    finally:
        cleanup(tmp)


def test_meta_sandbox_fail_dangerous():
    """测试 9: 沙盒测试 - 危险工具拒绝"""
    tmp = setup_test_workspace()
    try:
        meta = MetaAgent(tmp)
        
        design = {
            "agent_id": "bad-001",
            "source": "custom",
            "config": {
                "type": "hacker",
                "name": "Bad Agent",
                "model": "claude-sonnet-4-5",
                "timeout": 120,
                "tools_allow": ["exec", "gateway"],  # gateway 是危险工具
                "tools_deny": []
            }
        }
        
        result = meta.sandbox_test(design)
        assert not result["passed"], "Should fail: gateway in allow list"
        
        # 检查具体哪个测试失败
        perm_test = [t for t in result["tests"] if t["name"] == "permission_safety"]
        assert len(perm_test) == 1
        assert not perm_test[0]["passed"]
        
        print("✅ test_meta_sandbox_fail_dangerous")
    finally:
        cleanup(tmp)


def test_meta_approval_flow():
    """测试 10: 完整审批流程"""
    tmp = setup_test_workspace()
    try:
        meta = MetaAgent(tmp)
        
        # 设计
        gap = {"gap_type": "template_uncovered", "agent_type": "monitor", "severity": "medium"}
        design = meta.design_agent(gap)
        
        # 沙盒测试
        test_result = meta.sandbox_test(design)
        assert test_result["passed"]
        
        # 提交审批
        suggestion = meta.submit_for_approval(design, test_result)
        assert suggestion["status"] == "pending"
        
        # 列出待审批
        pending = meta.list_pending()
        assert len(pending) == 1
        
        # 批准
        result = meta.approve(suggestion["id"])
        assert result["ok"], f"Approve failed: {result}"
        
        # 验证已注册
        assert meta.registry.active_count() == 1
        
        # 待审批应该为空
        assert len(meta.list_pending()) == 0
        
        print("✅ test_meta_approval_flow")
    finally:
        cleanup(tmp)


def test_meta_reject_flow():
    """测试 11: 拒绝流程"""
    tmp = setup_test_workspace()
    try:
        meta = MetaAgent(tmp)
        
        gap = {"gap_type": "template_uncovered", "agent_type": "coder", "severity": "medium"}
        design = meta.design_agent(gap)
        test_result = meta.sandbox_test(design)
        suggestion = meta.submit_for_approval(design, test_result)
        
        # 拒绝
        result = meta.reject(suggestion["id"], "Not needed right now")
        assert result["ok"]
        
        # 待审批为空
        assert len(meta.list_pending()) == 0
        
        # 历史中有记录
        assert meta.state["agents_rejected"] == 1
        
        print("✅ test_meta_reject_flow")
    finally:
        cleanup(tmp)


def test_meta_heartbeat_frequency():
    """测试 12: 心跳频率控制"""
    tmp = setup_test_workspace()
    try:
        meta = MetaAgent(tmp)
        
        # 第一次心跳
        result1 = meta.heartbeat()
        assert result1 == "META_AGENT_OK"
        
        # 立即再次心跳（应该被频率控制跳过）
        result2 = meta.heartbeat()
        assert result2 == "META_AGENT_OK"
        
        # 验证 last_scan 已设置
        assert meta.state["last_scan"] is not None
        
        print("✅ test_meta_heartbeat_frequency")
    finally:
        cleanup(tmp)


def test_meta_failure_detection():
    """测试 13: 失败模式检测"""
    tmp = setup_test_workspace()
    try:
        meta = MetaAgent(tmp)
        
        # 写入模拟失败 traces
        traces_file = tmp / "aios" / "agent_system" / "data" / "traces" / "agent_traces.jsonl"
        with open(traces_file, "w", encoding="utf-8") as f:
            for i in range(5):
                trace = {
                    "timestamp": datetime.now().isoformat(),
                    "status": "failed",
                    "task_type": "deployment",
                    "error": f"Deployment failed: timeout #{i}"
                }
                f.write(json.dumps(trace) + "\n")
        
        gaps = meta.detect_gaps()
        failure_gaps = [g for g in gaps if g["gap_type"] == "frequent_failure"]
        assert len(failure_gaps) >= 1, f"Should detect failure pattern, got: {gaps}"
        assert failure_gaps[0]["agent_type"] == "deployment"
        
        print("✅ test_meta_failure_detection")
    finally:
        cleanup(tmp)


def test_registry_find_by_type():
    """测试 14: 按类型查找"""
    tmp = setup_test_workspace()
    try:
        reg = DynamicRegistry(tmp)
        
        reg.register("coder-1", {"type": "coder"})
        reg.register("coder-2", {"type": "coder"})
        reg.register("monitor-1", {"type": "monitor"})
        
        coders = reg.find_by_type("coder")
        assert len(coders) == 2
        
        monitors = reg.find_by_type("monitor")
        assert len(monitors) == 1
        
        print("✅ test_registry_find_by_type")
    finally:
        cleanup(tmp)


def test_registry_stats():
    """测试 15: 统计信息"""
    tmp = setup_test_workspace()
    try:
        reg = DynamicRegistry(tmp)
        
        reg.register("a1", {"type": "coder"})
        reg.register("a2", {"type": "monitor"})
        reg.update_activity("a1", success=True)
        reg.update_activity("a1", success=True)
        reg.update_activity("a1", success=False)
        
        stats = reg.get_stats()
        assert stats["active"] == 2
        assert stats["slots_available"] == 13
        assert stats["total_tasks"] == 3
        
        print("✅ test_registry_stats")
    finally:
        cleanup(tmp)


def test_meta_format_report():
    """测试 16: 报告格式化"""
    tmp = setup_test_workspace()
    try:
        meta = MetaAgent(tmp)
        
        # 无待审批
        report = meta.format_pending_report()
        assert "没有" in report
        
        # 添加一个待审批
        gap = {"gap_type": "test", "agent_type": "coder", "description": "Test gap", "severity": "medium"}
        design = meta.design_agent(gap)
        test_result = meta.sandbox_test(design)
        meta.submit_for_approval(design, test_result)
        
        report = meta.format_pending_report()
        assert "待审批" in report
        assert "coder" in report
        
        print("✅ test_meta_format_report")
    finally:
        cleanup(tmp)


if __name__ == "__main__":
    tests = [
        test_registry_basic,
        test_registry_max_limit,
        test_registry_cleanup_idle,
        test_registry_protected,
        test_meta_detect_gaps,
        test_meta_design_from_template,
        test_meta_design_custom,
        test_meta_sandbox_pass,
        test_meta_sandbox_fail_dangerous,
        test_meta_approval_flow,
        test_meta_reject_flow,
        test_meta_heartbeat_frequency,
        test_meta_failure_detection,
        test_registry_find_by_type,
        test_registry_stats,
        test_meta_format_report,
    ]
    
    passed = 0
    failed = 0
    
    for test in tests:
        try:
            test()
            passed += 1
        except Exception as e:
            print(f"❌ {test.__name__}: {e}")
            failed += 1
    
    print(f"\n{'='*40}")
    print(f"Results: {passed}/{passed+failed} passed")
    if failed == 0:
        print("🎉 All tests passed!")
    else:
        print(f"⚠️ {failed} tests failed")
