"""
测试任务优先级队列
验证 high/normal/low 三级优先级
"""

import json
import time
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from aios.agent_system.auto_dispatcher import AutoDispatcher


def test_priority_queue():
    """测试优先级队列"""
    workspace = Path(__file__).parent.parent.parent
    dispatcher = AutoDispatcher(workspace)

    print("=== 测试任务优先级队列 ===\n")

    # 清空队列
    queue_file = workspace / "aios" / "agent_system" / "task_queue.jsonl"
    if queue_file.exists():
        queue_file.unlink()

    # 创建不同优先级的任务
    tasks = [
        {"type": "code", "message": "Low priority task 1", "priority": "low"},
        {"type": "code", "message": "Normal priority task 1", "priority": "normal"},
        {"type": "code", "message": "High priority task 1", "priority": "high"},
        {"type": "code", "message": "Low priority task 2", "priority": "low"},
        {"type": "code", "message": "Normal priority task 2", "priority": "normal"},
        {"type": "code", "message": "High priority task 2", "priority": "high"},
    ]

    print("入队任务（按顺序）：")
    for i, task in enumerate(tasks, 1):
        dispatcher.enqueue_task(task)
        print(f"  {i}. {task['message']} [{task['priority']}]")
        time.sleep(0.1)  # 确保时间戳不同

    print()

    # 读取队列
    print("队列状态（入队后）：")
    with open(queue_file, "r", encoding="utf-8") as f:
        queued = [json.loads(line) for line in f if line.strip()]
    
    for i, task in enumerate(queued, 1):
        print(f"  {i}. {task['message']} [{task['priority']}] (id={task['id']})")

    print()

    # 模拟处理（不实际执行，只看排序）
    print("处理顺序（按优先级排序后）：")
    
    priority_order = {"high": 0, "normal": 1, "low": 2}
    sorted_tasks = sorted(
        queued,
        key=lambda t: (
            priority_order.get(t.get("priority", "normal"), 1),
            t.get("enqueued_at", "")
        )
    )

    for i, task in enumerate(sorted_tasks, 1):
        print(f"  {i}. {task['message']} [{task['priority']}]")

    print()

    # 验证优先级
    print("=== 验证结果 ===")
    
    # 检查前两个是否都是 high
    if sorted_tasks[0]["priority"] == "high" and sorted_tasks[1]["priority"] == "high":
        print("✅ High 优先级任务排在最前")
    else:
        print("❌ High 优先级任务未排在最前")

    # 检查中间两个是否都是 normal
    if sorted_tasks[2]["priority"] == "normal" and sorted_tasks[3]["priority"] == "normal":
        print("✅ Normal 优先级任务排在中间")
    else:
        print("❌ Normal 优先级任务未排在中间")

    # 检查最后两个是否都是 low
    if sorted_tasks[4]["priority"] == "low" and sorted_tasks[5]["priority"] == "low":
        print("✅ Low 优先级任务排在最后")
    else:
        print("❌ Low 优先级任务未排在最后")

    print()

    # 测试延迟处理（low 优先级）
    print("=== 测试 Low 优先级延迟处理 ===")
    print("当有 high/normal 任务时，low 任务会被跳过")
    print("只有队列空闲时，low 任务才会被处理")


if __name__ == "__main__":
    test_priority_queue()
