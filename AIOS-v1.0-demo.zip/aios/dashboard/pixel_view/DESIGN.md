# Pixel Agents 可视化设计文档

## 概述
为 AIOS Agent System 打造像素风虚拟办公室，让 Agent 的工作状态可视化、更直观、更有趣。

**灵感来源：** Pixel Agents 项目（抖音 @DobbyAi）

---

## 核心功能

### 1. 虚拟办公室
- 像素风场景（办公室、会议室、监控室、图书馆）
- Agent 以像素角色形式出现
- 实时显示 Agent 位置和状态

### 2. Agent 状态可视化
| 状态 | 动画 | 位置 |
|------|------|------|
| idle | 喝咖啡、看窗外 | 休息区 |
| running | 敲代码、看文档 | 工位 |
| degraded | 头上冒烟、抓头 | 工位（红色警告） |
| learning | 看书、记笔记 | 图书馆 |
| meeting | 站在白板前 | 会议室 |

### 3. 多 Agent 协作可视化
- coder 和 analyst 在会议室讨论
- monitor 在监控室盯屏幕
- researcher 在图书馆查资料
- 任务传递用"纸飞机"动画

---

## 技术架构

```
aios/
  dashboard/
    pixel_view/
      index.html          # 主页面
      style.css           # 样式
      app.js              # 逻辑
      sprites/            # 像素图
        coder_idle.png
        coder_running.png
        coder_degraded.png
        analyst_idle.png
        monitor_running.png
        office_bg.png
        meeting_room_bg.png
      data/
        agents.json       # Agent 位置和状态
        events.json       # 最近事件
```

---

## 数据格式

### agents.json
```json
{
  "agents": [
    {
      "id": "coder-699258",
      "type": "coder",
      "name": "编码开发专员",
      "status": "running",
      "position": {"x": 100, "y": 150},
      "current_task": "优化 AIOS 架构",
      "last_active": 1771853760000
    },
    {
      "id": "analyst-688334",
      "type": "analyst",
      "name": "数据分析专员",
      "status": "idle",
      "position": {"x": 300, "y": 150},
      "current_task": null,
      "last_active": 1771850000000
    }
  ]
}
```

### events.json
```json
{
  "events": [
    {
      "timestamp": 1771853760000,
      "type": "agent.task_started",
      "agent_id": "coder-699258",
      "message": "开始分析 AIOS 架构"
    },
    {
      "timestamp": 1771853700000,
      "type": "agent.task_completed",
      "agent_id": "analyst-688334",
      "message": "完成数据分析报告"
    }
  ]
}
```

---

## 实施步骤

### Phase 1: 基础框架（2-3h）
- [x] 设计文档
- [ ] HTML 页面结构
- [ ] CSS 像素风样式
- [ ] JavaScript 基础逻辑
- [ ] WebSocket 连接（复用 Dashboard 的）

### Phase 2: 像素图资源（3-4h）
- [ ] 找开源像素风素材（itch.io / OpenGameArt）
- [ ] 设计 Agent 角色（4 种类型 x 4 种状态 = 16 张图）
- [ ] 设计场景背景（办公室、会议室、监控室）
- [ ] 设计动画效果（纸飞机、冒烟、打字）

### Phase 3: 动画和交互（2-3h）
- [ ] Agent 移动动画
- [ ] 状态切换动画
- [ ] 任务传递动画
- [ ] 鼠标悬停显示详情
- [ ] 点击 Agent 查看历史

### Phase 4: 数据集成（1-2h）
- [ ] 从 AIOS Agent System 读取数据
- [ ] 实时更新 agents.json
- [ ] 实时更新 events.json
- [ ] WebSocket 推送更新

---

## 像素图资源

### 推荐素材库
1. **itch.io** - https://itch.io/game-assets/free/tag-pixel-art
2. **OpenGameArt** - https://opengameart.org/
3. **Kenney** - https://kenney.nl/assets（免费，CC0 协议）
4. **Pixel Art Maker** - 在线工具，自己画

### 需要的素材
- [ ] 办公室背景（800x600）
- [ ] 办公桌 x4
- [ ] 电脑 x4
- [ ] 白板
- [ ] 书架
- [ ] 咖啡机
- [ ] 角色（4 种类型，每种 4 个状态）

---

## UI 布局

```
+--------------------------------------------------+
|  AIOS Pixel Agents                    [Dashboard]|
+--------------------------------------------------+
|                                                  |
|   [办公区]                                        |
|   🧑‍💻 Coder    🧑‍💻 Analyst                        |
|   (running)   (idle)                             |
|                                                  |
|   [会议室]                                        |
|   🧑‍💼 Meeting...                                 |
|                                                  |
|   [监控室]                                        |
|   📊 Monitor (watching)                          |
|                                                  |
+--------------------------------------------------+
|  最近事件：                                       |
|  • coder-699258: 开始分析 AIOS 架构 (2s ago)      |
|  • analyst-688334: 完成数据分析 (5m ago)          |
+--------------------------------------------------+
```

---

## 下一步

1. 先做 Phase 1（基础框架）
2. 找开源像素图素材
3. 实现基础动画
4. 集成 AIOS 数据

**预计时间：** 8-10 小时  
**优先级：** P2（锦上添花）  
**风险：** 低

---

**开始时间：** 2026-02-24 00:22
