# Dashboard 使用指南

## 目录
- [简介](#简介)
- [启动方法](#启动方法)
- [界面说明](#界面说明)
- [决策卡片解读](#决策卡片解读)
- [实时监控](#实时监控)
- [数据分析](#数据分析)
- [故障排查](#故障排查)

---

## 简介

AIOS Dashboard 是一个实时监控工具，用于可视化 UnifiedRouter 的决策过程。

**核心功能：**
- 📊 **实时决策卡片** - WebSocket 推送最新决策
- 📈 **统计指标** - Agent 分布、模型使用、决策延迟
- 🔍 **决策审计** - 完整的决策历史和理由
- 🎯 **置信度分析** - 决策质量评估

**技术栈：**
- 后端：FastAPI + WebSocket
- 前端：原生 HTML/CSS/JS（无依赖）
- 数据：JSONL 日志文件

---

## 启动方法

### 方法 1：Python 脚本

```bash
# 进入项目目录
cd aios

# 启动 Dashboard
python start_dashboard.py

# 输出：
# INFO:     Started server process [12345]
# INFO:     Uvicorn running on http://127.0.0.1:8765
# INFO:     Application startup complete.
```

### 方法 2：批处理脚本（Windows）

```bash
# 双击运行
aios/dashboard/start_dashboard.bat

# 或命令行
cd aios/dashboard
start_dashboard.bat
```

### 方法 3：直接运行

```bash
# 使用 uvicorn
cd aios
uvicorn dashboard.router_dashboard:app --host 127.0.0.1 --port 8765

# 使用 Python 模块
python -m aios.dashboard.router_dashboard
```

### 访问 Dashboard

启动后，在浏览器打开：
```
http://127.0.0.1:8765
```

### 停止 Dashboard

```bash
# Windows
aios/dashboard/stop_dashboard.bat

# Linux/Mac
pkill -f router_dashboard

# 或直接 Ctrl+C
```

---

## 界面说明

### 整体布局

```
┌─────────────────────────────────────────────────────────┐
│  AIOS Router Dashboard - 决策卡片                        │
│  实时监控 UnifiedRouter 的每次决策                       │
├─────────────────────────────────────────────────────────┤
│  [统计指标区域]                                          │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐  │
│  │总决策数  │ │平均置信度│ │Opus使用  │ │平均延迟  │  │
│  │   156    │ │   0.87   │ │   45%    │ │  23ms    │  │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘  │
├─────────────────────────────────────────────────────────┤
│  [决策卡片区域 - 瀑布流]                                 │
│  ┌─────────────────────────────────────────────────┐   │
│  │ 🐛 debugger / opus-4-6 / high                   │   │
│  │ 高错误率 35.0% / sticky_applied                 │   │
│  │ 置信度: 0.95 | 14:30:25 | 15ms                  │   │
│  └─────────────────────────────────────────────────┘   │
│  ┌─────────────────────────────────────────────────┐   │
│  │ 💻 coder / opus-4-6 / medium                    │   │
│  │ 编码任务                                         │   │
│  │ 置信度: 0.80 | 14:28:10 | 12ms                  │   │
│  └─────────────────────────────────────────────────┘   │
│  ...                                                    │
└─────────────────────────────────────────────────────────┘
```

### 统计指标区域

**总决策数（Total Decisions）**
- 显示自启动以来的总决策次数
- 实时更新

**平均置信度（Avg Confidence）**
- 所有决策的平均置信度（0-1）
- 高于 0.8 为绿色，0.6-0.8 为黄色，低于 0.6 为红色

**Opus 使用率（Opus Usage）**
- Opus 模型使用占比
- 用于监控成本

**平均延迟（Avg Latency）**
- 决策平均耗时（毫秒）
- 用于监控性能

### 决策卡片区域

**卡片布局：**
```
┌─────────────────────────────────────────────────┐
│ [Agent Icon] agent_type / model / thinking      │  ← 标题行
│ reason_codes                                    │  ← 理由行
│ 置信度: 0.95 | 14:30:25 | 15ms                  │  ← 元数据行
│ [展开按钮]                                       │  ← 详情按钮
└─────────────────────────────────────────────────┘
```

**Agent 图标：**
- 💻 coder - 代码开发
- 🐛 debugger - 调试专家
- ⚡ optimizer - 性能优化
- 📊 analyst - 数据分析
- 👁️ monitor - 系统监控
- 🔍 researcher - 信息研究
- 🏗️ architect - 架构师
- 👀 reviewer - 代码审查
- 📝 documenter - 文档专员
- 🌐 translator - 翻译专员
- 🤖 automation - 自动化专员
- 🚀 deployer - 部署专员
- 🔧 full-stack - 全栈工程师
- 🧪 tester - 测试工程师

**颜色编码：**
- 绿色边框 - 高置信度（≥ 0.8）
- 黄色边框 - 中置信度（0.6-0.8）
- 红色边框 - 低置信度（< 0.6）

---

## 决策卡片解读

### 卡片示例 1：高错误率触发 debugger

```
┌─────────────────────────────────────────────────┐
│ 🐛 debugger / opus-4-6 / high                   │
│ 高错误率 35.0% / sticky_applied                 │
│ 置信度: 0.95 | 14:30:25 | 15ms                  │
└─────────────────────────────────────────────────┘
```

**解读：**
- **Agent**: debugger（调试专家）
- **Model**: opus-4-6（高级模型）
- **Thinking**: high（深度思考）
- **Reason**: 高错误率 35.0%（系统错误率超过阈值）
- **Reason**: sticky_applied（防抖机制生效，沿用上次 agent）
- **Confidence**: 0.95（高置信度）
- **Time**: 14:30:25（决策时间）
- **Latency**: 15ms（决策耗时）

**含义：** 系统检测到高错误率（35%），触发 debugger agent，使用 Opus 模型进行深度分析。由于防抖机制，沿用了上次的 agent 选择，置信度很高。

### 卡片示例 2：性能下降触发 optimizer

```
┌─────────────────────────────────────────────────┐
│ ⚡ optimizer / opus-4-6 / high                   │
│ 性能下降 30.0%                                   │
│ 置信度: 0.85 | 14:32:10 | 18ms                  │
└─────────────────────────────────────────────────┘
```

**解读：**
- **Agent**: optimizer（性能优化专家）
- **Model**: opus-4-6（高级模型）
- **Thinking**: high（深度思考）
- **Reason**: 性能下降 30.0%（系统性能下降超过阈值）
- **Confidence**: 0.85（高置信度）

**含义：** 系统检测到性能下降（30%），触发 optimizer agent，使用 Opus 模型进行性能分析和优化。

### 卡片示例 3：预算限制降级模型

```
┌─────────────────────────────────────────────────┐
│ 💻 coder / sonnet-4-5 / medium                  │
│ 编码任务 / budget_exceeded                      │
│ 置信度: 0.75 | 14:35:00 | 12ms                  │
└─────────────────────────────────────────────────┘
```

**解读：**
- **Agent**: coder（代码开发）
- **Model**: sonnet-4-5（标准模型，而非 opus-4-6）
- **Thinking**: medium（中等思考）
- **Reason**: 编码任务（任务类型匹配）
- **Reason**: budget_exceeded（Opus 配额用完，自动降级）
- **Confidence**: 0.75（中等置信度）

**含义：** 这是一个编码任务，本应使用 Opus 模型，但由于预算限制（Opus 配额用完），自动降级到 Sonnet 模型。置信度略低，因为模型降级可能影响质量。

### 卡片示例 4：失败回退触发人工介入

```
┌─────────────────────────────────────────────────┐
│ ❌ needs_human / - / -                          │
│ max_failures_reached / failure_count: 3         │
│ 置信度: 0.00 | 14:40:00 | 10ms                  │
└─────────────────────────────────────────────────┘
```

**解读：**
- **Agent**: needs_human（需要人工介入）
- **Model**: -（无模型）
- **Thinking**: -（无思考）
- **Reason**: max_failures_reached（达到最大失败次数）
- **Reason**: failure_count: 3（失败 3 次）
- **Confidence**: 0.00（无置信度）

**含义：** 同一任务失败 3 次后，系统判断无法自动解决，触发人工介入标志。需要人工审查任务和错误日志。

### 卡片示例 5：CRITICAL 风险任务

```
┌─────────────────────────────────────────────────┐
│ 🚀 deployer / opus-4-6 / high                   │
│ CRITICAL 风险 / 部署任务                         │
│ 置信度: 0.90 | 14:45:00 | 20ms                  │
└─────────────────────────────────────────────────┘
```

**解读：**
- **Agent**: deployer（部署专员）
- **Model**: opus-4-6（高级模型）
- **Thinking**: high（深度思考）
- **Reason**: CRITICAL 风险（极高风险任务）
- **Reason**: 部署任务（任务类型匹配）
- **Confidence**: 0.90（高置信度）

**含义：** 这是一个 CRITICAL 风险的部署任务，系统自动选择最高级的模型和思考级别，确保安全性。

---

## 实时监控

### WebSocket 连接

Dashboard 使用 WebSocket 实现实时推送：

```javascript
// 前端代码（自动连接）
const ws = new WebSocket('ws://127.0.0.1:8765/ws');

ws.onmessage = (event) => {
    const decision = JSON.parse(event.data);
    addDecisionCard(decision);  // 添加新卡片
    updateStats();              // 更新统计
};

ws.onerror = () => {
    // 回退到 HTTP 轮询
    setInterval(fetchDecisions, 5000);
};
```

**连接状态：**
- 🟢 绿点 - WebSocket 已连接（实时推送）
- 🔴 红点 - WebSocket 断开（HTTP 轮询）

### HTTP 轮询（回退方案）

如果 WebSocket 连接失败，自动回退到 HTTP 轮询：

```javascript
// 每 5 秒拉取一次
setInterval(() => {
    fetch('/api/decisions?limit=20')
        .then(res => res.json())
        .then(data => updateDecisions(data));
}, 5000);
```

### 数据刷新

**实时数据：**
- 决策卡片 - WebSocket 推送（< 100ms 延迟）
- 统计指标 - 每次新决策自动更新

**历史数据：**
- 页面加载时读取最近 20 条决策
- 支持滚动加载更多

---

## 数据分析

### API 端点

Dashboard 提供以下 API 端点：

#### 1. 获取决策列表

```bash
GET /api/decisions?limit=20

# 响应
[
    {
        "task_id": "task-001",
        "agent": "debugger",
        "model": "opus-4-6",
        "thinking": "high",
        "reason_codes": ["high_error_rate", "sticky_applied"],
        "confidence": 0.95,
        "decided_at": "2025-02-22T14:30:25Z",
        "decision_time_ms": 15
    },
    ...
]
```

#### 2. 获取统计信息

```bash
GET /api/stats

# 响应
{
    "total_decisions": 156,
    "avg_confidence": 0.87,
    "opus_usage": 0.45,
    "avg_latency_ms": 23,
    "agent_distribution": {
        "coder": 45,
        "debugger": 32,
        "optimizer": 28,
        ...
    },
    "model_distribution": {
        "opus-4-6": 70,
        "sonnet-4-5": 86
    }
}
```

#### 3. WebSocket 实时推送

```bash
WS /ws

# 推送格式（每次新决策）
{
    "type": "new_decision",
    "data": {
        "task_id": "task-001",
        "agent": "debugger",
        ...
    }
}
```

### 使用 curl 查询

```bash
# 获取最近 10 条决策
curl http://127.0.0.1:8765/api/decisions?limit=10 | jq

# 获取统计信息
curl http://127.0.0.1:8765/api/stats | jq

# 查看 agent 分布
curl http://127.0.0.1:8765/api/stats | jq '.agent_distribution'

# 查看模型使用
curl http://127.0.0.1:8765/api/stats | jq '.model_distribution'
```

### 使用 Python 分析

```python
import requests
import json

# 获取决策数据
resp = requests.get('http://127.0.0.1:8765/api/decisions?limit=100')
decisions = resp.json()

# 分析置信度分布
confidences = [d['confidence'] for d in decisions]
avg_confidence = sum(confidences) / len(confidences)
print(f"Average confidence: {avg_confidence:.2f}")

# 分析 agent 使用
from collections import Counter
agents = [d['agent'] for d in decisions]
agent_counts = Counter(agents)
print("Agent distribution:")
for agent, count in agent_counts.most_common():
    print(f"  {agent}: {count}")

# 分析决策延迟
latencies = [d.get('decision_time_ms', 0) for d in decisions]
avg_latency = sum(latencies) / len(latencies)
print(f"Average latency: {avg_latency:.1f}ms")
```

### 导出数据

```bash
# 导出决策日志
cp aios/data/router_decisions.jsonl ~/backup/decisions_$(date +%Y%m%d).jsonl

# 转换为 CSV
cat aios/data/router_decisions.jsonl | \
  jq -r '[.task_id, .agent, .model, .confidence, .decided_at] | @csv' > decisions.csv

# 导入到数据库（示例）
cat aios/data/router_decisions.jsonl | \
  mongoimport --db aios --collection decisions --type json
```

---

## 故障排查

### 问题 1：Dashboard 无法启动

**症状：** 运行 `python start_dashboard.py` 报错

**可能原因：**
1. 端口 8765 被占用
2. 缺少依赖（fastapi, uvicorn）

**解决方案：**

```bash
# 检查端口占用
netstat -ano | findstr 8765  # Windows
lsof -i :8765                # Linux/Mac

# 杀死占用进程
taskkill /PID <PID> /F       # Windows
kill -9 <PID>                # Linux/Mac

# 安装依赖
pip install fastapi uvicorn websockets

# 使用其他端口
uvicorn dashboard.router_dashboard:app --port 8766
```

### 问题 2：无决策卡片显示

**症状：** Dashboard 启动成功，但无卡片显示

**可能原因：**
1. 决策日志文件不存在
2. 使用 simple 模式（不写日志）

**解决方案：**

```bash
# 检查日志文件
ls -lh aios/data/router_decisions.jsonl

# 如果不存在，切换到 full 模式
# 在代码中：
router = UnifiedRouter(mode="full", data_dir="aios/data")

# 手动创建测试数据
echo '{"task_id":"test-001","agent":"coder","model":"opus-4-6","thinking":"medium","reason_codes":["编码任务"],"confidence":0.8,"decided_at":"2025-02-22T14:00:00Z","decision_time_ms":10}' >> aios/data/router_decisions.jsonl
```

### 问题 3：WebSocket 连接失败

**症状：** 页面显示红点，无实时推送

**可能原因：**
1. 防火墙阻止 WebSocket
2. 代理服务器不支持 WebSocket

**解决方案：**

```bash
# 检查 WebSocket 连接
# 浏览器控制台（F12）查看错误信息

# 使用 HTTP 轮询（自动回退）
# Dashboard 会自动切换到 HTTP 轮询模式

# 配置防火墙允许 WebSocket
# Windows: 控制面板 → 防火墙 → 高级设置 → 入站规则
# Linux: sudo ufw allow 8765/tcp
```

### 问题 4：统计数据不准确

**症状：** 统计指标与实际不符

**可能原因：**
1. 日志文件损坏
2. 缓存未清除

**解决方案：**

```bash
# 验证日志文件
cat aios/data/router_decisions.jsonl | jq . > /dev/null
# 如果报错，说明文件损坏

# 清除损坏的行
cat aios/data/router_decisions.jsonl | jq -c . > temp.jsonl
mv temp.jsonl aios/data/router_decisions.jsonl

# 刷新浏览器缓存
# Ctrl+Shift+R (Chrome/Firefox)
# Cmd+Shift+R (Mac)
```

### 问题 5：决策延迟过高

**症状：** 平均延迟 > 100ms

**可能原因：**
1. 使用 full 模式（护栏开销）
2. 磁盘 I/O 慢（日志写入）

**解决方案：**

```bash
# 切换到 simple 模式
router = UnifiedRouter(mode="simple")

# 优化日志写入（批量写入）
# production_router.py
def _log_decision(self, plan: Plan):
    # 使用缓冲区，每 10 条写入一次
    self.decision_buffer.append(plan)
    if len(self.decision_buffer) >= 10:
        self._flush_buffer()

# 使用 SSD 存储日志
# 将 data_dir 指向 SSD 分区
```

---

## 高级功能

### 自定义卡片样式

编辑 `dashboard/router_dashboard.py` 中的 CSS：

```css
/* 修改卡片颜色 */
.decision-card {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

/* 修改高置信度边框 */
.decision-card.high-confidence {
    border-left: 4px solid #10b981;  /* 绿色 */
}

/* 修改低置信度边框 */
.decision-card.low-confidence {
    border-left: 4px solid #ef4444;  /* 红色 */
}
```

### 添加自定义指标

```python
# dashboard/router_dashboard.py

@app.get("/api/stats")
async def get_stats():
    decisions = get_recent_decisions(limit=1000)
    
    # 自定义指标：失败率
    failure_count = sum(1 for d in decisions if d.get('agent') == 'needs_human')
    failure_rate = failure_count / len(decisions) if decisions else 0
    
    # 自定义指标：平均复杂度
    complexities = [d.get('input_snapshot', {}).get('complexity', 0) for d in decisions]
    avg_complexity = sum(complexities) / len(complexities) if complexities else 0
    
    return {
        "total_decisions": len(decisions),
        "failure_rate": failure_rate,
        "avg_complexity": avg_complexity,
        ...
    }
```

### 导出报告

```python
# 生成 HTML 报告
import json
from datetime import datetime

decisions = get_recent_decisions(limit=1000)

html = f"""
<html>
<head><title>AIOS Router Report</title></head>
<body>
<h1>AIOS Router Report</h1>
<p>Generated: {datetime.now()}</p>
<h2>Summary</h2>
<ul>
  <li>Total Decisions: {len(decisions)}</li>
  <li>Avg Confidence: {sum(d['confidence'] for d in decisions) / len(decisions):.2f}</li>
</ul>
<h2>Decisions</h2>
<table border="1">
  <tr><th>Task ID</th><th>Agent</th><th>Model</th><th>Confidence</th></tr>
  {''.join(f'<tr><td>{d["task_id"]}</td><td>{d["agent"]}</td><td>{d["model"]}</td><td>{d["confidence"]:.2f}</td></tr>' for d in decisions)}
</table>
</body>
</html>
"""

with open('report.html', 'w') as f:
    f.write(html)
```

---

## 总结

AIOS Dashboard 提供了强大的实时监控和决策审计功能：

**核心功能：**
- 实时决策卡片（WebSocket 推送）
- 统计指标（Agent 分布、模型使用、决策延迟）
- 决策审计（完整的决策历史和理由）
- 置信度分析（决策质量评估）

**使用场景：**
- 开发调试 - 实时查看路由决策
- 生产监控 - 监控系统健康度
- 性能分析 - 分析决策延迟和质量
- 审计合规 - 完整的决策历史记录

**最佳实践：**
- 使用 full 模式生成决策日志
- 定期备份决策日志文件
- 监控统计指标（置信度、延迟）
- 分析低置信度决策，优化路由逻辑

更多信息请参考：
- [UnifiedRouter Guide](../agent_system/UNIFIED_ROUTER_GUIDE.md) - 路由器使用指南
- [Developer Guide](../agent_system/DEVELOPER_GUIDE.md) - 开发者指南
